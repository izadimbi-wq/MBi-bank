package com.example.portfoliomanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.NumberFormat
import java.util.Locale

data class Holding(
    val symbol:String, val date:String, val quantity:Int, val bonus:Int, val rights:Int,
    val value:Double, val lastPrice:Double, val lastPricePct:Double, val closePrice:Double,
    val closePct:Double, val dailyPL:Double, val dividendLastPeriod:Double,
    val dividendLast:Double, val dividendTotal:Double, val pl:Double, val plPct:Double,
    val avgBuy:Double, val buyValue:Double, val avgSell:Double, val sellValue:Double,
    val soldPL:Double, val description:String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val seed = assets.open("portfolio_seed.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<Holding>>() {}.type
        val initial = Gson().fromJson<List<Holding>>(seed, type)
        setContent { PortfolioApp(initial) }
    }
}

@Composable
fun PortfolioApp(initial: List<Holding>) {
    var holdings by remember { mutableStateOf(initial) }
    var cash by remember { mutableStateOf(35_000_000.0) }
    var tab by remember { mutableIntStateOf(0) }

    val value = holdings.sumOf { it.value }
    val daily = holdings.sumOf { it.dailyPL }
    val pl = holdings.sumOf { it.pl }
    val total = value + cash

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides
        androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("داشبورد","سهام","سوابق","گزارش‌ها").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            label = { Text(title) }, icon = {}
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> Dashboard(total, value, cash, daily, pl)
                    1 -> HoldingsScreen(holdings)
                    2 -> HistoryScreen()
                    3 -> ReportsScreen(holdings, cash)
                }
            }
        }
    }
}

@Composable
fun Dashboard(total:Double, value:Double, cash:Double, daily:Double, pl:Double) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("مدیریت پرتفوی", fontSize=28.sp, style=MaterialTheme.typography.headlineSmall) }
        item { Metric("دارایی کل", money(total)) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)){ Metric("ارزش پرتفوی", money(value)) }
                Box(Modifier.weight(1f)){ Metric("مانده نقدی", money(cash)) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)){ Metric("سود امروز", money(daily)) }
                Box(Modifier.weight(1f)){ Metric("سود پرتفوی", money(pl)) }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("وضعیت", style=MaterialTheme.typography.titleMedium)
                    Text("این برنامه فقط مدیریت اطلاعات و ثبت سوابق است و هیچ سفارش خرید یا فروشی به کارگزاری ارسال نمی‌کند.")
                }
            }
        }
    }
}

@Composable fun Metric(t:String,v:String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) { Text(t); Spacer(Modifier.height(5.dp)); Text(v, fontSize=19.sp) }
    }
}

@Composable
fun HoldingsScreen(items:List<Holding>) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { Text("سهام", fontSize=26.sp, style=MaterialTheme.typography.headlineSmall) }
        items(items) { h ->
            Card {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(h.symbol, style=MaterialTheme.typography.titleLarge)
                        Text("تعداد ${num(h.quantity)}")
                    }
                    Text(h.description)
                    Text("قیمت: ${money(h.lastPrice)}")
                    Text("ارزش: ${money(h.value)}")
                    Text("سود/زیان: ${money(h.pl)}  (${pct(h.plPct)})")
                    Text("سود امروز: ${money(h.dailyPL)}")
                    Text("سهام جایزه: ${num(h.bonus)}   حق‌تقدم: ${num(h.rights)}")
                }
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("ثبت سوابق", fontSize=26.sp)
        Button(onClick={}, Modifier.fillMaxWidth()){ Text("ثبت خرید") }
        Button(onClick={}, Modifier.fillMaxWidth()){ Text("ثبت فروش") }
        Button(onClick={}, Modifier.fillMaxWidth()){ Text("ثبت سهام جایزه") }
        Button(onClick={}, Modifier.fillMaxWidth()){ Text("ثبت سود مجمع") }
        OutlinedButton(onClick={}, Modifier.fillMaxWidth()){ Text("ثبت / اصلاح مانده نقدی") }
        Text("در نسخه بعدی فرم‌های ثبت، ویرایش و حذف رویدادها به پایگاه داده محلی متصل می‌شوند.")
    }
}

@Composable
fun ReportsScreen(items:List<Holding>, cash:Double) {
    val value=items.sumOf{it.value}; val pl=items.sumOf{it.pl}; val div=items.sumOf{it.dividendTotal}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("گزارش‌ها", fontSize=26.sp) }
        item { Metric("ارزش پرتفوی", money(value)) }
        item { Metric("مانده نقدی", money(cash)) }
        item { Metric("سود/زیان فعلی", money(pl)) }
        item { Metric("سود نقدی کل مجامع", money(div)) }
        item { Metric("دارایی کل", money(value+cash)) }
    }
}

fun money(v:Double)=NumberFormat.getNumberInstance(Locale("fa","IR")).format(v)+" تومان"
fun num(v:Int)=NumberFormat.getNumberInstance(Locale("fa","IR")).format(v)
fun pct(v:Double)=String.format(Locale.US,"%.2f%%",v)
